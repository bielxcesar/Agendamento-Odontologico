package com.aula.agendamento_odontologico.Controller;

import com.aula.agendamento_odontologico.dto.DadosCadastroDentista;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/dentista")
@RestController
public class ControllerDentista {
    @PostMapping
    public void cadastroDentista(@RequestBody DadosCadastroDentista dentista) {
        System.out.println(dentista );
    }
}
