package com.aula.agendamento_odontologico.dto;

import jakarta.persistence.Embeddable;

@Embeddable
public record Endereco(
        String logradouro,
        String bairro,
        String cep,
        String cidade,
        String uf,
        String numero,
        String complemento
) {
}
