package com.aula.agendamento_odontologico.model;

import jakarta.persistence.Embeddable;

public class Endereco {
    private String logradouro;
    private String bairro;
    private String cep;
    private String cidade;
    private String uf;
    private String numero;
    private String complemento;
}
