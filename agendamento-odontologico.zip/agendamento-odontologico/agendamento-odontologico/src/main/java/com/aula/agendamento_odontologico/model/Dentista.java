package com.aula.agendamento_odontologico.model;

import com.aula.agendamento_odontologico.dto.Endereco;
import com.aula.agendamento_odontologico.enums.Especialidade;
import jakarta.persistence.*;
import lombok.*;

@Table(name = "dentista")
@Entity(name = "Dentista")
@AllArgsConstructor
@NoArgsConstructor
@Getter
//comparar id entre objeto e tabela
@EqualsAndHashCode(of = "id")
public class Dentista {
    //Identificar o id com chave primary key
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nome;
    private String email;
    private String cro;
    @Enumerated(EnumType.STRING)
    private Especialidade especialidade;
    @Embedded
    private Endereco endereco;

}
