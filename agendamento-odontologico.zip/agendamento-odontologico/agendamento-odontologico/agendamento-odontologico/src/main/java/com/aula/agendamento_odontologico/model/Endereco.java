package com.aula.agendamento_odontologico.model;

import com.aula.agendamento_odontologico.dto.DtoEndereco;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Embeddable

public class Endereco {
    private String logradouro;
    private String bairro;
    private String cep;
    private String cidade;
    private String uf;
    private String numero;
    private String complemento;

    public Endereco(DtoEndereco dtoEndereco) {
        this.logradouro = dtoEndereco.logradouro();
        this.bairro = dtoEndereco.bairro();
        this.cep = dtoEndereco.cep();
        this.cidade = dtoEndereco.cidade();
        this.uf = dtoEndereco.uf();
        this.numero = dtoEndereco.numero();
        this.complemento = dtoEndereco.complemento();
    }
}
