package com.aula.agendamento_odontologico.model;

import com.aula.agendamento_odontologico.dto.DadosCadastroDentista;
import com.aula.agendamento_odontologico.dto.DtoEndereco;
import com.aula.agendamento_odontologico.enums.Especialidade;
import jakarta.persistence.*;
import lombok.*;

@Table(name = "dentista")
@Entity(name = "Dentista")
@AllArgsConstructor
@NoArgsConstructor
@Getter
//comparar id entre objeto e tabela
@EqualsAndHashCode(of = "id")
public class Dentista {
    //Identificar o id com chave primary key
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nome;
    private String email;
    private String cro;
    @Enumerated(EnumType.STRING)
    private Especialidade especialidade;
    @Embedded
    private Endereco endereco;


    public Dentista(DadosCadastroDentista Dadosdentista) {
        this.nome = Dadosdentista.nome();
        this.email = Dadosdentista.email();
        this.cro = Dadosdentista.cro();
        this.especialidade = Dadosdentista.especialidade();
        this.endereco = new Endereco(Dadosdentista.endereco());
    }
}
