package com.aula.agendamento_odontologico.Controller;

import com.aula.agendamento_odontologico.dto.DadosCadastroDentista;
import com.aula.agendamento_odontologico.model.Dentista;
import com.aula.agendamento_odontologico.repository.DentistaRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/dentista")
@RestController
public class ControllerDentista {
    @Autowired
    private DentistaRepository repository;
    @PostMapping
    public void cadastroDentista(@RequestBody @Valid DadosCadastroDentista dadosdentista) {

        repository.save(new Dentista(dadosdentista));

    }
}
